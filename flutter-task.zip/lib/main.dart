import 'dart:html';

import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => SignInScreen(),
        '/signup': (context) => SignUpScreen(),
        '/home': (context) => HomePage(),
      },
    );
  }
}

class SignInScreen extends StatefulWidget {
  @override
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  String registeredEmail = 'ahmed@gmail.com'; // مثال للإيميل المسجل
  String registeredPassword = '123456'; // مثال للباسورد

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff181515),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 40),
              Text('SIGN IN',
                  style: TextStyle(
                      color: Color(0xff26d42c),
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
              SizedBox(height: 20),
              TextField(
                style: TextStyle(color: Color(0xff26d42c)),
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: Color(0xff26d42c)),
                  prefixIcon: Icon(
                    Icons.email,
                    color: Color(0xff26d42c),
                  ),
                  border: OutlineInputBorder(),
                ),
                cursorColor: Color(0xff26d42c),
              ),
              SizedBox(height: 15),
              TextField(
                style: TextStyle(color: Color(0xff26d42c)),
                controller: passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(color: Color(0xff26d42c)),
                  prefixIcon: Icon(
                    Icons.lock,
                    color: Color(0xff26d42c),
                  ),
                  border: OutlineInputBorder(),
                ),
                cursorColor: Color(0xff26d42c),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xff26d42c),
                  foregroundColor: Color(0xffffffff),
                ),
                onPressed: () {
                  if (emailController.text == registeredEmail &&
                      passwordController.text == registeredPassword) {
                    Navigator.pushNamed(context, '/home',
                        arguments: emailController.text);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Invalid email or password')),
                    );
                  }
                },
                child: Text('Sign In'),
              ),
              SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/signup');
                },
                child: Text(
                  "Don't have an account? Sign Up",
                  style: TextStyle(
                      color: Color(0xff26d42c),
                      decoration: TextDecoration.underline),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SignUpScreen extends StatefulWidget {
  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  String? _gender;
  double _age = 18;
  bool receiveNotifications = false;
  bool agreeToTerms = false;

  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff181515),
      appBar: null,
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 20),
              TextField(
                style: TextStyle(color: Color(0xff26d42c)),
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: Color(0xff26d42c)),
                  prefixIcon: Icon(
                    Icons.email,
                    color: Color(0xff26d42c),
                  ),
                  border: OutlineInputBorder(),
                ),
                cursorColor: Color(0xff26d42c),
              ),
              SizedBox(
                height: 10,
              ),
              TextField(
                style: TextStyle(color: Color(0xff26d42c)),
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                  labelStyle: TextStyle(color: Color(0xff26d42c)),
                  prefixIcon: Icon(
                    Icons.lock,
                    color: Color(0xff26d42c),
                  ),
                  border: OutlineInputBorder(),
                ),
                cursorColor: Color(0xff26d42c),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: RadioListTile(
                      title: Text(
                        "Male",
                        style: TextStyle(color: Color(0xff26d42c)),
                      ),
                      value: "Male",
                      groupValue: _gender,
                      onChanged: (value) {
                        setState(() {
                          _gender = value.toString();
                        });
                      },
                    ),
                  ),
                  Expanded(
                    child: RadioListTile(
                      title: Text(
                        "Female",
                        style: TextStyle(color: Color(0xff26d42c)),
                      ),
                      value: "Female",
                      groupValue: _gender,
                      onChanged: (value) {
                        setState(() {
                          _gender = value.toString();
                        });
                      },
                    ),
                  ),
                ],
              ),
              DropdownButtonFormField(
                decoration: InputDecoration(
                  labelStyle: TextStyle(
                    color: Color(0xff26d42c),
                  ),
                  labelText: "Status",
                  border: OutlineInputBorder(),
                ),
                items: ["Single", "Married"]
                    .map((status) => DropdownMenuItem(
                          value: status,
                          child: Text(status),
                        ))
                    .toList(),
                onChanged: (value) {},
              ),
              SizedBox(height: 10),
              Text(
                "Age: ${_age.toInt()}",
                style: TextStyle(color: Color(0xff26d42c)),
              ),
              Slider(
                value: _age,
                min: 0,
                max: 100,
                divisions: 100,
                label: _age.toInt().toString(),
                onChanged: (value) {
                  setState(() {
                    _age = value;
                  });
                },
              ),
              SwitchListTile(
                title: Text(
                  "Receive Notifications",
                  style: TextStyle(color: Color(0xff26d42c)),
                ),
                value: receiveNotifications,
                onChanged: (value) {
                  setState(() {
                    receiveNotifications = value;
                  });
                },
              ),
              Row(
                children: [
                  Checkbox(
                    value: agreeToTerms,
                    onChanged: (value) {
                      setState(() {
                        agreeToTerms = value!;
                      });
                    },
                  ),
                  Expanded(
                      child: Text(
                    "I agree to the Terms and Conditions",
                    style: TextStyle(color: Color(0xff26d42c)),
                  )),
                ],
              ),
              TextField(
                style: TextStyle(
                  color: Color(0xff26d42c),
                ),
                decoration: InputDecoration(
                  labelText: "Notes",
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xff26d42c),
                  foregroundColor: Color(0xffffffff),
                ),
                onPressed: () {
                  print("Sign Up Info:");
                  print("Email: ${_emailController.text}");
                  print("Password: ${_passwordController.text}");
                  print("Gender: $_gender");
                  print("Age: ${_age.toInt()}");
                  print("Notifications: $receiveNotifications");
                  print("Agree to Terms: $agreeToTerms");

                  Navigator.pop(context);
                },
                child: Text("Sign Up"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Map<String, dynamic>> products = [
    {
      'name': 'Iphone',
      'image': Icons.shopping_bag,
      'liked': false,
      'dislike': false,
      'add': false
    },
    {
      'name': 'Samsung',
      'image': Icons.shopping_basket,
      'liked': false,
      'dislike': false,
      'add': false
    },
    {
      'name': 'Realme',
      'image': Icons.shop,
      'liked': false,
      'dislike': false,
      'add': false
    },
    {
      'name': 'Oppo',
      'image': Icons.shopping_bag,
      'liked': false,
      'dislike': false,
      'add': false
    },
    {
      'name': 'Infinix',
      'image': Icons.shopping_basket,
      'liked': false,
      'dislike': false,
      'add': false
    },
    {
      'name': 'Huwawi',
      'image': Icons.shop,
      'liked': false,
      'dislike': false,
      'add': false
    },
    {
      'name': 'Redmi',
      'image': Icons.shop,
      'liked': false,
      'dislike': false,
      'add': false
    },
  ];

  @override
  Widget build(BuildContext context) {
    final String userEmail =
        ModalRoute.of(context)!.settings.arguments as String;

    return Scaffold(
      backgroundColor: Color(0xff253a44),
      appBar: null,
      body: Column(
        children: [
          SizedBox(
            height: 20,
          ),
          Text(
            'Welcome',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Color(0xff26d42c),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Text('$userEmail',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xff26d42c),
              )),
          SizedBox(
            height: 20,
          ),
          Expanded(
            child: ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                return Card(
                  child: ListTile(
                    tileColor: Color(0xff264e9a),
                    leading: Icon(products[index]['image'],
                        size: 40, color: Color(0xff181515)),
                    title: Text(products[index]['name'],
                        style: TextStyle(color: Color(0xff181515))),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(
                            Icons.favorite,
                            color: products[index]['liked']
                                ? Colors.red
                                : Color(0xff181515),
                          ),
                          onPressed: () {
                            setState(() {
                              products[index]['liked'] =
                                  !products[index]['liked'];
                              if (products[index]['dislike'] ==
                                  products[index]['liked']) {
                                !products[index]['dislike'];
                              }
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                  content: Text(
                                      '${products[index]['name']} liked!')),
                            );
                          },
                        ),
                        IconButton(
                          icon: Icon(
                            Icons.thumb_down,
                            color: products[index]['dislike']
                                ? Colors.blue
                                : Color(0xff181515),
                          ),
                          onPressed: () {
                            setState(() {
                              products[index]['dislike'] =
                                  !products[index]['dislike'];
                              if (products[index]['liked'] ==
                                  products[index]['dislike']) {
                                !products[index]['liked'];
                              }
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                  content: Text(
                                      '${products[index]['name']} disliked!')),
                            );
                          },
                        ),
                        IconButton(
                          icon: Icon(
                            Icons.add_shopping_cart,
                            color: products[index]['add']
                                ? Colors.yellow
                                : Color(0xff181515),
                          ),
                          onPressed: () {
                            setState(() {
                              products[index]['add'] = !products[index]['add'];
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                  content: Text(
                                      '${products[index]['name']} added to cart!')),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
